# Network Port Scanner

A simple Python TCP connect scanner for learning about ports and network services.

## Features
- Scans a user-specified host and port range
- Uses Python's socket library
- Reports TCP ports that accept a connection
- Includes basic input validation and a connection timeout

## Requirements
- Python 3.9+ (no third-party packages required)

## Run
```bash
python port_scanner.py
```
Enter a hostname or IP address and a port range, such as `1` to `1024`.

## Responsible use
Only scan systems you own or have explicit permission to test. Scanning networks without authorization may violate policies or laws. This tool is for educational use and does not identify every service or vulnerability.
