#!/usr/bin/env python3
"""Basic TCP port scanner for authorized lab use only."""
import ipaddress
import socket


def validate_target(target: str) -> str:
    target = target.strip()
    if not target or any(ch.isspace() for ch in target):
        raise ValueError("Enter a valid hostname or IP address.")
    # Resolve once so invalid names fail early; allow hostnames as well as IPs.
    socket.getaddrinfo(target, None, type=socket.SOCK_STREAM)
    return target


def scan_port(target: str, port: int, timeout: float = 0.4) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        return sock.connect_ex((target, port)) == 0


def main() -> None:
    print("TCP Port Scanner — authorized lab use only")
    target_input = input("Target hostname/IP (only with permission): ")
    try:
        target = validate_target(target_input)
        start = int(input("Start port (1-65535): "))
        end = int(input("End port (1-65535): "))
        if not (1 <= start <= end <= 65535):
            raise ValueError("Ports must satisfy 1 <= start <= end <= 65535.")
    except (ValueError, socket.gaierror, OSError) as exc:
        print(f"Invalid input: {exc}")
        return

    try:
        resolved = socket.gethostbyname(target)
    except socket.gaierror as exc:
        print(f"Could not resolve target: {exc}")
        return

    print(f"\\nScanning {target} ({resolved}), ports {start}-{end}...")
    open_ports = []
    for port in range(start, end + 1):
        try:
            if scan_port(resolved, port):
                print(f"Port {port}: OPEN")
                open_ports.append(port)
        except OSError:
            continue

    print(f"\\nFinished. {len(open_ports)} open TCP port(s) found.")
    if not open_ports:
        print("No open ports found in the selected range.")


if __name__ == "__main__":
    main()
